
gsap.from(".hero-text", {duration: 1, y: 50, opacity: 0, ease: "power4.out"});
gsap.from(".character", {duration: 1.2, x: -100, opacity: 0, ease: "elastic.out(1, 0.5)"});
gsap.utils.toArray(".feature-card").forEach((card, i) => {
  gsap.to(card, {
    scrollTrigger: {
      trigger: card,
      start: "top 80%",
      toggleActions: "play none none reverse"
    },
    duration: 0.8,
    opacity: 1,
    y: 0,
    delay: i * 0.15,
    ease: "power2.out"
  });
});
lottie.loadAnimation({
  container: document.getElementById('lottie-container'),
  renderer: 'svg',
  loop: true,
  autoplay: true,
  path: 'assets/lottie/animation.json'
});
